DEFAULT_OS_IMAGE = "" # TODO: complete `tower` image will be online
DEFAULT_OS_SHA256 = ""
DEFAULT_SSH_USER = "tower"
DEFAULT_SSH_PORT = 22
